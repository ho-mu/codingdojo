$(document).ready(function(){
            
    $('form').submit(function(){
        var firstName = $('input[type=text][name=first_name]').val();
        var lastName = $('input[type=text][name=last_name]').val();
        var email = $('input[type=text][name=email]').val();
        var phone = $('input[type=text][name=phone_number]').val();

        console.log("Adding user: ",firstName,lastName,email,phone);

        $('table').append("<tr><td>" + firstName + "</td>" + "<td>" + lastName + "</td>" + 
            "<td>" + email + "</td>" + "<td>" + phone + "</td>");

        $('input[type=text]').val("");

        return false;
    });

});